var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var ObjectId = require('mongodb').ObjectId; 

var emailValidator = require("email-validator");
var passwordValidator = require('password-validator');
const bcrypt = require('bcryptjs');
const saltRounds = 10;


var passport = require('passport');
var CustomStrategy = require('passport-custom');

var Utils=require('./utils');
const {PWD_SCHEMA,PHNUMBER_SCHEMA,NAME_SCHEMA,STORE,userModel} = require('./config');

mongoose.set('useFindAndModify', false);


/*
//add data to mongodb
var user1 = userModel({name:'pkw',email:'pkw@pkw.com',phnumber:'7066506779',password:'pkw'}).save(function(err){
  if(err) throw err;
  console.log('user added.');
});
*/


//params
var loginErrors = new Object();



var app = express();
app.set('view engine','ejs');
app.use('/assets',express.static('assets'));
app.use(require('express-session')({
  secret: 'kjhasdkjhkasdk',
  store: STORE,
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 24 * 7 // 1 week
  }
  //cookie: { secure: true }
}));
app.use(passport.initialize());
app.use(passport.session());
var urlencodedParser = bodyParser.urlencoded({ extended: false });


app.use(function(req,res,next){
  res.locals.isAuthenticated = req.isAuthenticated();
  res.locals.isUser = req.user;
  next();
});

app.get('/', function(req,res) {
  res.render('home',{});
});

app.get('/home', function(req,res) {
  res.render('home',{});
});

app.get('/contact', function(req,res) {
  res.render('contact',{});
});

//login related routines

passport.use(new CustomStrategy(
  function(req, done) {
    userModel.find({email:req.body.email},function(err,data){
      if(err) throw err;

      if(data.length === 0 || data.length >1 ) {
        console.log('zero or more than 1 user with same email!');
        return done(null,false);
      }

      bcrypt.compare(req.body.pwd,data[0].password,function(err,response){
        if(response === true) {
          req.login(data[0]._id,function(err) {
            return done(null, data[0]._id);
          });
        }
        else {
          loginErrors.success = false;
          //console.log('password do not match! invalid!');
          return done(null,false);
        }
      });
  }
)}));

app.get('/login', function(req,res) {
  console.log(req.user);
  console.log(req.isAuthenticated());
  res.render('login',{errors:loginErrors});
});

app.post('/login',urlencodedParser,passport.authenticate('custom',
{ failureRedirect: '/login' }),
  function(req, res) {
    res.redirect('/profile');
  }
);

//logout related
app.get('/logout',function(req,res) {
  req.logout();
  req.session.destroy();
  res.redirect('/');
});

//signup related
app.get('/register', function(req,res) {
  var error = new Object();
  res.render('register',{errors:error});
});

app.post('/register',urlencodedParser,function(req,res){
  registerUser(req.body.name,req.body.phnumber,req.body.email,req.body.pwd,req.body.pwd2,function(err,error){
  if(err)
    console.log('Error while register user : ',err);
  res.render('register',{errors: error});
  });
});

//profile related
app.get('/profile',authenticationMiddleware(), function(req,res) {
  getProfile(req.user,function(err,profile){
  if(err)
    console.log('Error --',err);

  getBalance(req.user,function(err,result){
    if(err)
      console.log('Error while fetching balance-',err);
    var profileBalance = new Object();
    profileBalance.balance=result.balance;
    res.render('profile',{profileData:profile,profileBalanceData:profileBalance});
  });   
  });
});

app.post('/profile-update',urlencodedParser,authenticationMiddleware(),function(req,res){
  updateProfile(req.user,req.body.email,req.body.phnumber,function(err,profile){
    if(err)
      console.log('Error while profile update--',err);
    getBalance(req.user,function(err,result) {
      if(err)
        console.log('Error while fetching balance--',err);
      var profileBalance = new Object();
      profileBalance.balance=result.balance;

      res.render('profile',{profileData:profile,profileBalanceData:profileBalance});
    });
  });
});


//transactions
app.get('/completed-transactions',authenticationMiddleware(), function(req,res) {
  getCompletedTransactions(req.user,function(err,result){
    if(err)
      console.log('Error while fetching completed transactions-',err);
    console.log(result);
    var completedTransactions = new Object();
    completedTransactions.data = result;
    completedTransactions.success = true;
    res.render('completed-transactions',{transactionData:completedTransactions});
  });
});

app.get('/pending-transactions',authenticationMiddleware(), function(req,res) {
  getPendingTransactions(req.user,function(err,result){
    if(err)
      console.log('Error while fetching pending transactions-',err);
    var pendingTransactions = new Object();
    console.log(result);
    pendingTransactions.data = result;
    pendingTransactions.success = true;
    res.render('pending-transactions',{transactionData:pendingTransactions});
  });
});

app.get('/transactions',authenticationMiddleware(), function(req,res) {  
  getBalance(req.user,function(err,result){
    if(err)
      console.log('Error while fetching balance-',err);
    var transaction = new Object();
    transaction.isGet = true;
    transaction.balance=result.balance;

    res.render('transactions',{transactionData:transaction});
  });

  
});

app.post('/transactions',urlencodedParser,authenticationMiddleware(), function(req,res) {
  makeTransaction(req.user,req.body.recipient,Number(req.body.ammount),function(err,result){
  if(err)
    console.log('Error while making transactions',err);
  var transaction = new Object();
  transaction.Tid = result.Tid;
  transaction.ammount = result.Ammount;
  transaction.balance = result.Balance;
  transaction.recipient = result.recipientAddress;
  transaction.sender = result.senderAddress;
  transaction.status = result.status; 
  transaction.success = true;
  res.render('transactions',{transactionData:transaction});
  });
});



app.get('/test', function(req,res) {
  userModel.find({uname:'pkw'},function(err,data){
    if(err) throw err;
    console.log(req.user);
    console.log(req.isAuthenticated());
    res.render('test',{dataz:data});
  });
});




app.listen(3000,function(){
         console.log('walletio Server started at 3000');
});


//service routines
passport.serializeUser(function(user_id, done) {
  done(null, user_id);
});

passport.deserializeUser(function(user_id, done) {
    done(null, user_id);
});

function authenticationMiddleware () {
	return (req, res, next) => {
		console.log(`req.session.passport.user: ${JSON.stringify(req.session.passport)}`);

	    if (req.isAuthenticated()) return next();
	    res.redirect('/login')
	}
}

//backend calls
function getProfile(user_id,cb)
{
  userModel.findOne({"_id":new ObjectId(user_id)},function(err,data){
      if(err) throw err;
      if (data.isWalletCreated) {
      var profile = new Object();
          profile.publicKey =  data.publicKey;
          profile.privateKey = data.privateKey;
          profile.balance = data.balance;
          profile.email = data.email;
          profile.phnumber = data.phnumber;
          profile.success = true;
      cb(null,profile);
        } 
      else {
        //hit create user endpoint
        Utils.GETjson('/create-user',function(err,result){
          if(err)
             console.log('Error while GET request : ',err);

          userModel.findOneAndUpdate({"_id":new ObjectId(user_id)},
            {$set:{publicKey:result.publicKey,privateKey:result.privateKey,balance:result.balance,isWalletCreated:true}},
            {new: true},(err,doc) => {
              if(err)
                console.log('Error while updating database!',err);
        var profile = new Object();
        profile.email = doc.email;
        profile.phnumber = doc.phnumber;
        profile.balance = doc.balance;
        profile.publicKey = doc.publicKey;
        profile.privateKey = doc.privateKey;
        profile.success = true;
        cb(null,profile);
            });
        });
      }
   });
}

function registerUser(name,phnumber,email,pwd1,pwd2,cb)
{
  var error = new Object();
  //validate 
  var isNameOk  = NAME_SCHEMA.validate(name);
  var isPhnumberOk = PHNUMBER_SCHEMA.validate(phnumber);
  var isEmailOk  = emailValidator.validate(email);
  var isPwdOK  = PWD_SCHEMA.validate(pwd1);
  
  
  var isPwd2Ok;
  if(pwd1 === pwd2)
    isPwd2Ok = true;
  else
    isPwd2Ok = false;

  if(!isNameOk)
    error.names =true;
  if(!isPhnumberOk)
    error.phone = true;
  if(!isEmailOk)
    error.email = true;
  if(!isPwdOK)
    error.password = true;
  if(!isPwd2Ok)
    error.password2 = true;

  var isExistsOk=false;
  
  userModel.find({email:email},function(err,data){
      if(err) throw err;

      if(data.length === 0 || data.length >1 )
       {
        error.exists = true;
        exval=true;
       }
   });

  if( (isNameOk && isPhnumberOk && isEmailOk && isPwdOK && isPwd2Ok=== true) && (isExistsOk === false) )
  {
    bcrypt.hash(pwd1, saltRounds, function(err, hash) {
    // Store hash in your password DB.
    var userEntry = userModel({name:name,phnumber:phnumber,email:email ,password:hash})
  .save(function(err){
      if(err) throw err;
      });
    });
    error.success = true;
   }
   else
   {
     error.success= false;
   }
   
   cb(null,error);
}


function getCompletedTransactions(user_id,cb)
{
  userModel.findOne({"_id":new ObjectId(user_id)},function(err,data) {
  if(err) throw err;
  Utils.POSTjson('/get-completed-user-transactions',{"publicKey":data.publicKey},function(err,result){
    cb(null,result);
  });
  });
}

function getPendingTransactions(user_id,cb)
{
  userModel.findOne({"_id":new ObjectId(user_id)},function(err,data) {
  if(err) throw err;
  Utils.POSTjson('/get-pending-user-transactions',{"publicKey":data.publicKey},function(err,result){
    cb(null,result);
  });
  });
}

function makeTransaction(user_id,recipient,ammount,cb)
{
  userModel.findOne({"_id":new ObjectId(user_id)},function(err,data){
  if(err) throw err;
  Utils.POSTjson('/launch-user-transaction',
  {"recipient":recipient,"ammount":ammount,"privateKey":data.privateKey,"publicKey":data.publicKey},function(err,result) {
    cb(null,result);
  });
  });
}

function getBalance(user_id,cb)
{
  userModel.findOne({"_id":new ObjectId(user_id)},function(err,data){
    Utils.POSTjson('/get-user-balance',{"publicKey":data.publicKey},function(err,result){
      cb(null,result);
    });
  });
}

function updateProfile(user_id,email,phnumber,cb)
{
  var profile = new Object();
  var isEmailOk  = emailValidator.validate(email);
  var isPhnumberOk = PHNUMBER_SCHEMA.validate(phnumber);

  if(!isEmailOk)
  {
    profile.errorEmail =true;
  }
  if(!isPhnumberOk)
  {
    profile.errorPhone = true;
  }

  if(isEmailOk && isPhnumberOk === true)
  {
    userModel.findOneAndUpdate({"_id":new ObjectId(user_id)},
            {$set:{email:email,phnumber:phnumber}},
            {new: true},(err,doc) => {
              if(err)
                console.log('Error while updating database!',err);
              profile.email = doc.email;
              profile.phnumber = doc.phnumber;
              profile.balance = doc.balance;
              profile.publicKey = doc.publicKey;
              profile.privateKey = doc.privateKey;
              profile.success = true;
              cb(null,profile);
            });
  }
  else
  {
    cb(null,profile);
  }
}

