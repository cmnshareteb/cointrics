var http = require('http');
var request = require('request');
const {HOST,PORT} = require('./config');

class utils
{
	static GETjson(path,cb)
	{
		var options = {
			host: HOST,
			port: PORT,
			path: path,
			method: 'GET'
		};

		http.request(options,function(res){
		var body = '';
		res.on('data',function(chunk){
			body +=chunk;
		});
		res.on('end',function(){
			var result = JSON.parse(body);
			cb(null,result);
		});
		res.on('error',cb);
		})
		.on('error',cb)
		.end();
	}

	static POSTjson(path,senddata,cb)
	{
		var options={
			host: HOST,
			port: PORT,
			path:path,
			method: 'POST',
			headers :{
				'Content-Type': 'application/json'
			}
		};
		var req = http.request(options,function(res){
			var body='';
			res.on('data',function(chunk){
				body +=chunk;
				var result = JSON.parse(body);
				cb(null,result);
			});
		});
		
		req.on('error',function(e){
			console.log('Error while POST request',e.message);
		});
		
		req.write(JSON.stringify(senddata));
		req.end();
	}

	static POSTjson2(path,senddata,cb)
	{
		var options={
			host: HOST,
			port: PORT,
			path:path,
			method: 'POST',
			headers :{
				'Content-Type': 'application/json'
			}
		};
		var req = http.request(options,function(res){
			var body='';
			res.on('data',function(chunk){
				body +=chunk;
				var result = body;
				cb(null,result);
			});
		});
		
		req.on('error',function(e){
			console.log('Error while POST request',e.message);
		});
		
		req.write(JSON.stringify(senddata));
		req.end();
	}
}

module.exports = utils;
