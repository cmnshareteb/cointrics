npm i nodemon --save-dev
npm install body-parser --save
npm install mongoose --save
npm install express --save
npm install express-session --save
npm install ejs  --save
npm install email-validator --save

npm install password-validator

npm install bcryptjs --save
npm install connect-mongodb-session --save

npm install passport-custom --save

npm install passport --save

npm install mongoose-unique-validator --save
npm install mongodb --save
npm install --save request
npm install --save http


nodemon index.js


upon registration options -- save private key with walletio (encoded with walletio, ie no need to put in priv-key while transacting)
							 save private key with passphrase encoding
							 Dont save anywhere, (shown only once & download)

forgot passord
change mail,number,pwd,passphrase form--(reverify all)
change private key settings later
verify email & phone

//setting-- fill my keys automaticaly
/*
 save db		//reciepient,ammount -- easy
 flash & download keys.txt		//user freedom,privacy
 save db encry , decry key -walletio //key recover
 save db encr, decry key - user passphrase //security,privacy
*/
