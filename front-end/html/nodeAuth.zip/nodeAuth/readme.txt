body-parser,mongoose,express,ejs
npm install email-validator --save
npm install password-validator
npm install bcrypt
connect-mongodb-session

npm install passport-custom --save

nodemon index.js
