//npm install express --save
//<% include nav.ejs%>
var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

var emailValidator = require("email-validator");
var passwordValidator = require('password-validator');
const bcrypt = require('bcrypt');
const saltRounds = 10;

var session = require('express-session');
var passport = require('passport');
var CustomStrategy = require('passport-custom');

//session store
var MongoDBStore = require('connect-mongodb-session')(session);
var store = new MongoDBStore({
  uri: 'mongodb://cmnshareteb:cmnshareteb1@ds161062.mlab.com:61062/walletio',
  collection: 'mySessions'
});
// Catch errors
store.on('error', function(error) {
  assert.ifError(error);
  assert.ok(false);
});

//connect to db
mongoose.connect('mongodb://cmnshareteb:cmnshareteb1@ds161062.mlab.com:61062/walletio',{ useNewUrlParser: true });
//create schema for database
var userSchema = new mongoose.Schema({
  name: String,
  email: String,
  phnumber : String,
  password : String
});
var userModel = mongoose.model('user',userSchema);
/*
//add data to mongodb
var user1 = userModel({name:'pkw',email:'pkw@pkw.com',phnumber:'7066506779',password:'pkw'}).save(function(err){
  if(err) throw err;
  console.log('user added.');
});
*/
//schema for password,name,phonenumber
// Create  schema
var pwdSchema = new passwordValidator();
pwdSchema
.is().min(8)                                    // Minimum length 8
.is().max(100)                                  // Maximum length 100
//.has().uppercase()                              // Must have uppercase letters
.has().lowercase()                              // Must have lowercase letters
.has().digits()                                 // Must have digits
.has().not().spaces()                           // Should not have spaces
.is().not().oneOf(['Passw0rd', 'Password123']); // Blacklist these values

var phnumberSchema = new passwordValidator();
phnumberSchema
.is().min(10)
.is().max(10)
.has().digits()
.has().not().symbols()
.has().not().lowercase()
.has().not().uppercase()
.has().not().spaces();

var nameSchema = new passwordValidator();
nameSchema
.is().min(3)
.is().max(50)
.has().not().symbols()
.has().not().digits();
//test user adding


var app = express();
app.set('view engine','ejs');
app.use('/assets',express.static('assets'));
app.use(require('express-session')({
  secret: 'kjhasdkjhkasdk',
  store: store,
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 24 * 7 // 1 week
  }
  //cookie: { secure: true }
}));
app.use(passport.initialize());
app.use(passport.session());

app.use(function(req,res,next){
  res.locals.isAuthenticated = req.isAuthenticated();
  next();
});

passport.use(new CustomStrategy(
  function(req, done) {
    userModel.find({email:req.body.email},function(err,data){
      if(err) throw err;

      if(data.length === 0 || data.length >1 ) {
        console.log('zero or more than 1 user with same email!');
        return done(null,false);
      }

      console.log('hased password');
      console.log(data[0].password);

      bcrypt.compare(req.body.pwd,data[0].password,function(err,response){
        if(response === true) {
          console.log('user_id:');
          console.log(data[0]._id);
          req.login(data[0]._id,function(err) {
            return done(null, data[0]._id);
          });
        }
        else {
          console.log('password do not match! invalid!');
          return done(null,false);
        }
      });
  }
)}));
var urlencodedParser = bodyParser.urlencoded({ extended: false });

app.get('/', function(req,res) {
  console.log(req.user);
  console.log(req.isAuthenticated());
  res.render('header',{});
});

app.get('/login', function(req,res) {
  console.log(req.user);
  console.log(req.isAuthenticated());
  res.render('login',{});
});

app.post('/login',urlencodedParser,passport.authenticate('custom',
{ failureRedirect: '/login' }),
  function(req, res) {
    res.redirect('/');
  }
);

app.get('/logout',function(req,res) {
  req.logout();
  req.session.destroy();
  res.redirect('/');
});

/*
app.post('/login', urlencodedParser, function (req, res) {
  console.log(req.body);
  //validate email & password
  var eval= emailValidator.validate(req.body.email);
  var pval= pwdSchema.validate(req.body.pwd);

   userModel.find({email:req.body.email},function(err,data){
     if(err) throw err;
     //var user_id = data[0].id;
     console.log('user_id:');
     console.log(data[0]._id);
     req.login(data[0]._id,function(error) {
       res.render('test',{dataz:data});
     });

   });

  //res.render('home',{data: req.body});
});
*/

app.get('/test', function(req,res) {
  userModel.find({uname:'pkw'},function(err,data){
    if(err) throw err;
    console.log(req.user);
    console.log(req.isAuthenticated());
    res.render('test',{dataz:data});
  });


});

app.get('/register', function(req,res) {
  res.render('register',{});
});

app.post('/register',urlencodedParser,function(req,res){
  console.log(req.body);
  //validate email & password
  var eval  = emailValidator.validate(req.body.email);
  var pval  = pwdSchema.validate(req.body.pwd);
  var nval  = nameSchema.validate(req.body.name);
  var phval = phnumberSchema.validate(req.body.phnumber);

  if( (eval && pval && nval && phval == true) && (req.body.pwd === req.body.pwd2) )
  {


    bcrypt.hash(req.body.pwd, saltRounds, function(err, hash) {
    // Store hash in your password DB.
    //Add new entry to database
    var userEntry = userModel({name:req.body.name,phnumber:req.body.phnumber.toString(),email:req.body.email ,password:hash}).save(function(err){
      if(err) throw err;
      console.log('user added to database.');
      });
    });
   }
   else
   {
     //display error dialogues
     console.log('email or password invalid!');
     console.log(req.body);
   }
  res.render('home',{data: req.body});
});

app.get('/profile',authenticationMiddleware(), function(req,res) {
  res.render('profile',{});
});

app.listen(3000,function(){
         console.log('walletio Server started at 3000');
});

passport.serializeUser(function(user_id, done) {
  done(null, user_id);
});

passport.deserializeUser(function(user_id, done) {
    done(null, user_id);
});

function authenticationMiddleware () {
	return (req, res, next) => {
		console.log(`req.session.passport.user: ${JSON.stringify(req.session.passport)}`);

	    if (req.isAuthenticated()) return next();
	    res.redirect('/login')
	}
}
