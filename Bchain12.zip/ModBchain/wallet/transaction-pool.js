const Transaction = require('./transaction');

class TransactionPool
{
	constructor()
	{
		this.transactions = [];
	}

	updateOrAddTransaction(transaction)
	{
		let transactionWithID = this.transactions.find(t => t.id === transaction.id);
		
		if (transactionWithID) 
		{
			this.transactions[this.transactions.indexOf(transactionWithID)] = transaction;
		}
		else
		{
			this.transactions.push(transaction);
		}

	}

	existingTransaction(address)
	{
		return this.transactions.find(t => t.input.address === address);
	}

	validTransactions()
	{
		return this.transactions.filter(transaction => {
			const outputTotal = transaction.outputs.reduce((total,output) => {
				return total + output.ammount;
			},0);

			if(transaction.input.ammount !== outputTotal)
			{
				console.log(`invalid transaction from ${transaction.input.address}`);
				return;
			}

			if(!Transaction.verifyTransaction(transaction))
			{
				console.log(`invalid signature from ${transaction.input.address}`);
				return;
			}

			return transaction;
		});
	}

	clear()
	{
		this.transactions = [];
	}

	static getTransactions(tp,publicKey)
	{
		let transactionx = [];
		let tnxobj;
		let txns=[];

		var id,recip,amt,bal;

		tp.transactions.forEach(transaction =>{
			transactionx.push(transaction);
		});

		const walletInputTs = transactionx.filter(transaction => transaction.input.address === publicKey);

		walletInputTs.forEach(transaction =>{
			id=transaction.id;
			transaction.outputs.find(output => {
				if(output.address === publicKey)
				{
					bal=output.ammount;
				}
				else
				{
					amt=output.ammount;
					recip=output.address;
				}
				tnxobj = {Tid:id,recipient:recip,ammount:amt,balance:bal,status:"pending"};
			});
			txns.push(tnxobj);
		});

		return txns;
	}

}

module.exports=TransactionPool;
