const ChainUtil =require('../chain-util');
const Transaction = require('./transaction');
const {INITIAL_BALANCE} = require('../config');

class Wallet
{
	constructor()
	{
		this.balance= INITIAL_BALANCE;
		this.keyPair= ChainUtil.genKeyPair();
		this.publicKey=this.keyPair.getPublic().encode('hex');
	}

	toString()
	{
		return `wallet-
		publicKey: ${this.publicKey.toString()}
		keyPair: ${this.keyPair}
		balance:${this.balance}
		`;
	}

	sign(dataHash)
	{
		return this.keyPair.sign(dataHash);
	}

	createTransaction(recipient,ammount,blockchain,transactionpool)
	{
		this.balance = this.calculateBalance(blockchain);
		if(ammount > this.balance)
		{
			console.log(`ammount :${ammount} exceeds the current balance :${this.balance}`);
			return;
		}
		let transaction=transactionpool.existingTransaction(this.publicKey);

		if(transaction)
		{
			transaction.update(this,recipient,ammount);
		}
		else
		{
			transaction=Transaction.newTransaction(this,recipient,ammount);
			transactionpool.updateOrAddTransaction(transaction);
		}

		return transaction;
	}

	calculateBalance(blockchain)
	{
		let balance = this.balance;
		let transactions = [];

		blockchain.chain.forEach(block => block.data.forEach(transaction => {
			transactions.push(transaction);
		}));

		const walletInputTs = transactions.filter(transaction => transaction.input.address === this.publicKey);

		let startTime =0;

		if(walletInputTs.length > 0)
		{
			const recentInputT= walletInputTs.reduce((prev,current) => prev.input.timestamp > current.input.timestamp ? prev : current);	
			balance = recentInputT.outputs.find(output => output.address === this.publicKey).ammount;
			startTime = recentInputT.input.timestamp;
		}

		transactions.forEach(transaction => {
			if(transaction.input.timestamp >startTime)
			{
				transaction.outputs.find(output => {
					if(output.address === this.publicKey)
					{
						balance += output.ammount;
					}
				});
			}
		});

		return balance;
	}

	static blockchainWallet()
	{
		const blockchainWallet = new this();
		blockchainWallet.address= 'blockchain-wallet';
		return blockchainWallet;
	}
	
}

module.exports = Wallet;
