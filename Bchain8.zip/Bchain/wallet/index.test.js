const Wallet = require('./index');
const TransactionPool = require('./transaction-pool');

describe('Wallet', () => {
	let wallet,tp;

	beforeEach(() => {
		wallet = new Wallet();
		tp = new TransactionPool();
	});

	describe('creatting a transaction',() => {

		let transaction,sendAmmount,recipient;

		beforeEach(() => {
			sendAmmount = 50;
			recipient = 'r4ndon-a44re55';
			transaction = wallet.createTransaction(recipient,sendAmmount,tp);
		});

		describe('& doing the same transaction',() => {
			beforeEach(() => {
				wallet.createTransaction(recipient,sendAmmount,tp);
			});

			it('doubles the `sendAmmount` subtracted from wallet balance',() => {
				expect(transaction.outputs.find(output => output.address === wallet.publicKey).ammount).toEqual(wallet.balance - sendAmmount*2);
			});

			it('clones the `sendAmmount` output for recipient',() => {
				expect(transaction.outputs.filter(output => output.address === recipient).map(output => output.ammount)).toEqual([sendAmmount,sendAmmount]);
			});
		});
	});
});
