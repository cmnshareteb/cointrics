const TransactionPool = require('./transaction-pool');
const Transaction = require('./transaction');
const Wallet = require('./index');


describe('TransactionPool',() => {
	let tp,wallet,transaction;

	beforeEach(() => {
		tp = new TransactionPool();
		wallet = new Wallet();
		transaction = Transaction.newTransaction(wallet,'rn4dop568',30)

		tp.updateOrAddTransaction(transaction);
	});


	it('Add a transaction to the transaction-pool', () => {
		expect(tp.transactions.find(t => t.id === transaction.id)).toEqual(transaction);
	});

	it('Updates a transaction in a pool',() => {
		const OldTranscaction = JSON.stringify(transaction);
		const NewTransaction = transaction.update(wallet,'n3wa44re55',40);
		tp.updateOrAddTransaction(NewTransaction);
		expect(JSON.stringify(tp.transactions.find(t => t.id === NewTransaction.id))).not.toEqual(OldTranscaction);
	});
});


