const ChainUtil =require('../chain-util');
const Transaction = require('./transaction');
const {INITIAL_BALANCE} = require('../config');

class Wallet
{
	constructor()
	{
		this.balance= INITIAL_BALANCE;
		this.keyPair= ChainUtil.genKeyPair();
		this.publicKey=this.keyPair.getPublic().encode('hex');
	}

	toString()
	{
		return `wallet-
		publicKey: ${this.publicKey.toString()}
		keyPair: ${this.keyPair}
		balance:${this.balance}
		`;
	}

	sign(dataHash)
	{
		return this.keyPair.sign(dataHash);
	}

	createTransaction(recipient,ammount,transactionpool)
	{
		if(ammount > this.balance)
		{
			console.log(`ammount :${ammount} exceeds the current balance :${this.balance}`);
			return;
		}
		let transaction=transactionpool.existingTransaction(this.publicKey);

		if(transaction)
		{
			transaction.update(this,recipient,ammount);
		}
		else
		{
			transaction=Transaction.newTransaction(this,recipient,ammount);
			transactionpool.updateOrAddTransaction(transaction);
		}

		return transaction;
	}
	
}

module.exports = Wallet;
