const Block=require('./block');

const blockx = new Block('foo','bar','zoo','test');

console.log(blockx.toString());

console.log(Block.genesis().toString());

const fooBlock = Block.mineBlock(Block.genesis(),'foo');
console.log(fooBlock.toString());