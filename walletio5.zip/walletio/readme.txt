npm i nodemon --save-dev
npm install body-parser --save
npm install mongoose --save
npm install express --save
npm install express-session --save
npm install ejs  --save
npm install email-validator --save

npm install password-validator

npm install bcryptjs --save
npm install connect-mongodb-session --save

npm install passport-custom --save

npm install passport --save

npm install mongoose-unique-validator --save
npm install mongodb --save
npm install --save request
npm install --save http
npm install --save secure-random

nodemon index.js



forgot passord
verify email & phone
buy & sell coins


mine transaction button
blocks page


https://instagram.com/pdification?utm_source=ig_profile_share&igshid=27ww8cklww36
https://instagram.com/rohan_663?utm_source=ig_profile_share&igshid=17w2rhbqf7v3e
https://instagram.com/_aditikulkarni_?utm_source=ig_profile_share&igshid=p3hdz3t8pyr9