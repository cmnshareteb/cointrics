####Section 2 creating block and testing###
##important commands

npm init -y //new npm project

npm i nodemon --save-dev

$ npm run dev-test


npm i crypto-js --save-dev

npm i jest --save-dev

npm run test
