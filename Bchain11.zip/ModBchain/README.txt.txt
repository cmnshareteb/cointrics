####Section 2 creating block and testing###
##important commands

npm init -y //new npm project

npm i nodemon --save-dev

$ npm run dev-test


npm i crypto-js --save-dev

npm i jest --save-dev

npm run test

npm i express --save

HTTP_PORT=3002 npm run dev

npm run dev

npm i body-parser --save

npm i ws --save

HTTP_PORT=3002 P2P_PORT=5002 PEERS=ws://localhost:5001 npm run dev

HTTP_PORT=3003 P2P_PORT=5003 PEERS=ws://localhost:5001,ws://localhost:5002 npm run dev

npm i elliptic --save

npm i uuid --save
