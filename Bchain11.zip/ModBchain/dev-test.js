const Wallet = require('./wallet');

const wallet = new Wallet();

console.log(wallet.toString());