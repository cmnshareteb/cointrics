const express = require('express');
const Blockchain = require('../blockchain');
const bodyParser = require('body-parser');
const P2pServer = require('./p2p-server');
const Wallet = require('../wallet');
const TransactionPool = require('../wallet/transaction-pool');
const Miner = require('./miner');
const HTTP_PORT =process.env.HTTP_PORT || 3001;
const EC = require('elliptic').ec;
const ec = new EC('secp256k1');


const app = express();
const bc = new Blockchain();
const wallet = new Wallet();
const tp = new TransactionPool();
const p2pserver = new P2pServer(bc,tp);
const miner = new Miner(bc,tp,wallet,p2pserver);


app.use(bodyParser.json({
    parameterLimit: 100000,
    limit: '50mb',
    extended: true
  }));

//miner specific calls
app.get('/blocks', (req,res) => {
	res.json(bc.chain);
});

app.post('/mine',(req,res) => {
	const block = bc.addBlock(req.body.data);
	console.log(`New block added: ${block.toString()}`);

	p2pserver.syncChains();
	res.redirect('/blocks');
});

app.get('/transactions',(req,res) => {
	res.json(tp.transactions);
});

app.get('/mine-transactions',(req,res) => {
	const block = miner.mine();
	console.log(`new block added : ${block.toString()}`);
	res.redirect('/blocks');
});

app.post('/transact',(req,res) => {
	const {recipient,ammount} = req.body;
	const transaction = wallet.createTransaction(recipient,ammount,bc,tp);
	p2pserver.broadcastTransaction(transaction);
	res.redirect('/transactions');
});

app.get('/public-key',(req,res) =>{
	res.json({publicKey:wallet.publicKey});
});

app.get('/balance',(req,res) => {
	const balance = wallet.calculateBalance(bc);
	res.json({Balance:balance});
});

//for wallet specific calls
app.get('/create-user',(req,res) => {
	const newWallet = new Wallet();
	var temp = JSON.parse(JSON.stringify(newWallet));
	res.json({balance:temp.balance,privateKey:temp.keyPair.priv,publicKey:temp.publicKey});
});

app.post('/load-user-balance',(req,res) => {
	const {recipient,ammount,balance,privateKey,publicKey} = req.body;
	const privateKeyPair = ec.keyFromPrivate(privateKey);
	var userWallet = new Wallet();
	userWallet.loadWallet(balance,privateKeyPair,publicKey);
	const newbalance = userWallet.calculateBalance(bc);
	res.json({balance:newbalance});
});


app.post('/launch-user-transaction',(req,res) => {
	const {recipient,ammount,balance,privateKey,publicKey} = req.body;
	const privateKeyPair = ec.keyFromPrivate(privateKey);
	var userWallet = new Wallet();
	userWallet.loadWallet(balance,privateKeyPair,publicKey);
	const transaction = userWallet.createTransaction(recipient,ammount,bc,tp);
	p2pserver.broadcastTransaction(transaction);
	//send success or failure as response
	res.redirect('/transactions');
});


app.listen(HTTP_PORT,() => console.log(`Listening on port ${HTTP_PORT}`));
p2pserver.listen();