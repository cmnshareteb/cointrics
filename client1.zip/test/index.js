var http = require('http');

var request = require('request');


var options= {
	host: 'localhost',
	port: 3001,
	path:'/blocks',
	method: 'GET'
};

http.request(options,function(res){
	var body='';

	res.on('data',function(chunk){
		body +=chunk;
	});

	res.on('end',function(){
		var price = JSON.parse(body);
		console.log(price);
		console.log(price[0].hash);
	});
}).end();

var user_data = {"data":"pkw4"};

var optionz = {
    host: 'localhost',
	port: 3001,
	path:'/mine',
	method: 'POST',
	headers :{
		'Content-Type': 'application/json',
	}

};

var req = http.request(optionz, function(res) {
  console.log('Status: ' + res.statusCode);
  console.log('Headers: ' + JSON.stringify(res.headers));
  res.setEncoding('utf8');
  res.on('data', function (body) {
    console.log('Body: ' + body);
  });
});
req.on('error', function(e) {
  console.log('problem with request: ' + e.message);
});
// write data to request body
req.write(JSON.stringify(user_data));
req.end();