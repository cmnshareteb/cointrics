const ChainUtil = require('../chain-util');

class Transaction
{
	constructor()
	{
		this.id=ChainUtil.id();
		this.input=null;
		this.outputs = [];
	}

	update(senderWallet,recipient,ammount)
	{
		const senderOutput = this.outputs.find(output => output.address === senderWallet.publicKey);

		if(ammount > senderOutput.ammount)
		{
			console.log(`Ammount: ${ammount} exceeds balance`);
			return;
		}

		senderOutput.ammount = senderOutput.ammount - ammount;
		this.outputs.push({ammount,address: recipient});
		Transaction.signTransaction(this,senderWallet);

		return this;
	}

	static newTransaction(senderWallet, recipient,ammount)
	{
		const transaction = new this();

		if(ammount > senderWallet.balance)
		{
			console.log(`Ammount : ${ammount} exceeds balance`);
			return;
		}

		transaction.outputs.push(...[
		{ammount: senderWallet.balance - ammount, address: senderWallet.publicKey },
		{ammount, address: recipient}
		]);

		Transaction.signTransaction(transaction,senderWallet);
		
		return transaction;
	}

	static signTransaction(tranasction,senderWallet)
	{
		tranasction.input = {
			timestamp : Date.now(),
			ammount : senderWallet.balance,
			address : senderWallet.publicKey,
			signature : senderWallet.sign(ChainUtil.hash(tranasction.outputs))
		}
	}

	static verifyTransaction(tranasction)
	{
		return ChainUtil.verifySignature(tranasction.input.address,tranasction.input.signature,ChainUtil.hash(tranasction.outputs));
	}
}

module.exports = Transaction;
