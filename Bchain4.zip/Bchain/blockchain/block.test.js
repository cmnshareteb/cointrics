const Block= require('./block');

describe('Block',()=> {

	let data,block,lastblock;

	beforeEach(() => {
		 data='bar';
		 lastblock=Block.genesis();
		 block=Block.mineBlock(lastblock,data);
	});

	it('sets `data` to match function',() => {
		expect(block.data).toEqual(data);
	});

	it('sets `lasthash` to match hash of last block', () => {
		expect(block.lasthash).toEqual(lastblock.hash);
	});
});

