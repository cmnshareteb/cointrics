const SHA256= require('crypto-js/sha256');

class Block
{
	constructor(timestamp,lasthash,hash,data)
	{
		this.timestamp=timestamp;
		this.lasthash=lasthash;
		this.hash=hash;
		this.data=data;
	}

	toString()
	{
		return `Block:
		Timestamp: ${this.timestamp}
		Lasthash: ${this.lasthash.substring(0,10)}
		hash: ${this.hash.substring(0,10)}
		Data: ${this.data}
		`;
	}

	static genesis()
	{
		return new this('genesis time','--------','First-hash-p97',[]);
	}

	static mineBlock(lastBlock,data)
	{
		const timestamp=Date.now();
		const lastHash= lastBlock.hash;
		const hash= Block.hash(timestamp,lastHash,data);

		return new this(timestamp,lastHash,hash,data);
	}

	static hash(timestamp,lasthash,data)
	{
		return SHA256(`${timestamp}${lasthash}${data}`).toString();
	}
}

module.exports=Block;

